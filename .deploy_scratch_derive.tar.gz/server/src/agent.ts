// Fluent server — the agent orchestrator.
// Runs a "turn" (a /fluent-* command or a learner chat message) over the LLM,
// persists every produced part into the SQLite bridge, and emits SSE events so
// the web UI renders incrementally (same contract opencode exposed).

import fs from "node:fs";
import path from "node:path";
import type { FluentDB, SessionRow, MessageRow } from "./db";
import { runTurn, type ToolDefinition, type TurnPart, type ModelConfig, type ToolStep, type TurnMetrics } from "./llm";
import { buildTools, normalizeCategory, type DeepEvaluator } from "./tools";
import { loadCommand } from "./commands";
import {
  resolveSessionTarget,
  resolveStopMode,
  isPaced,
  wrapUpNote,
  countGradedInText,
  KNOWN_SCORE,
  scoreOfReply,
  writingLengthNote,
  vocabularyDueNote,
  parseTopics,
  exerciseOnlyOf,
  isExerciseGuard,
  isFeedbackGuard,
  mergeFeedbackOnly,
  trailingExercise,
  topicsNote,
  lessonTarget,
  lessonSkillSlot,
  skillBadge,
  skillDebts,
  exerciseFingerprints,
  pruneHistory,
  historyBudget,
  estimateTokens,
  dailyFace,
  resolveDailyGoal,
  resolveReviewGate,
  reviewGateNote,
  NO_GATE,
  lessonNote,
  skillBlock,
  drillMaterial,
  parseFeedback,
  alignMarkersToScore,
  spliceFeedback,
  withAnswerInFront,
  alignLessonHeader,
  turnGuard,
  languageDirectionGuard,
  pictureGuard,
  hasExerciseHeader,
  alignExerciseNumber,
  bounceReason,
  followsCompetence,
  type AssignedCompetence,
  nextDueItem,
  nextDrill,
  type AssignedDrill,
  practiceNote,
  type AssignedItem,
  type LessonView,
  type ReviewGate,
} from "./pacing";
import {
  readDaily,
  bumpDaily,
  readTally,
  creditLesson,
  readPlan,
  writePlan,
  today as todayISO,
  type LessonPlan,
} from "./daily";

export interface SSEEvent {
  type: string;
  properties: Record<string, unknown>;
}

export interface TurnOutcome {
  info: Record<string, unknown>;
  parts: Record<string, unknown>[];
}

const AGENT_FILES: Record<string, string> = {
  learner: "learner.md",
  tutor: "tutor.md",
  "tutor-fast": "tutor-fast.md",
};

// Model per agent id (matches the routing in docs/dual-model).
export function modelForAgent(agent: string, models: Models): ModelConfig {
  if (agent === "tutor-fast") return models.face;
  return models.deep;
}

// Face→deep fallback: el face (12323) és una descàrrega opcional per velocitat.
// Si no respon, el tutor-fast corre amb el deep (12322) sense que l'usuari perdi
// res — només queda una línia al log del servidor (cap avís al xat).
async function faceHealthy(baseURL: string): Promise<boolean> {
  try {
    const origin = new URL(baseURL).origin;
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 2000);
    let ok = false;
    try {
      const res = await fetch(origin + "/health", { signal: ctrl.signal });
      ok = res.ok;
    } finally {
      clearTimeout(t);
    }
    return ok;
  } catch {
    return false;
  }
}

function isConnError(e: unknown): boolean {
  const m = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
  return /ECONNREFUSED|ENOTFOUND|fetch failed|failed to fetch|socket hang up|network|aborted/i.test(m);
}

export async function resolveModel(
  agent: string,
  models: Models
): Promise<{ model: ModelConfig; fellBack: boolean }> {
  const primary = modelForAgent(agent, models);
  if (agent !== "tutor-fast" || primary.name !== "face") return { model: primary, fellBack: false };
  if (await faceHealthy(primary.baseURL)) return { model: primary, fellBack: false };
  console.log(`[Fluent] face (${primary.baseURL}) no disponible → tutor-fast amb deep (${models.deep.baseURL})`);
  return { model: models.deep, fellBack: true };
}

export interface Models {
  deep: ModelConfig;
  face: ModelConfig;
}

interface TurnKind {
  kind: "message";
  text: string;
  agentArg: string;
}
// kind "command" is created by the caller and passed as the first user turn.

export class Agent {
  private db: FluentDB;
  private root: string;
  private dataDirFn: () => string;
  private models: Models;
  private deep: DeepEvaluator;
  private tools: ReturnType<typeof buildTools>;
  private emit: (e: SSEEvent) => void;
  private lastDailyBackup = "";
  /** Sessions already told to wrap up — the nudge is given once. */
  private wrappedUp = new Set<string>();
  /** The command a session opened with. Decides whether the review gate
   *  applies: starting straight into 📝/🗣️/📚/📖 is the learner saying what
   *  they want today, and that is allowed — once, at the start. */
  private sessionOpenedWith = new Map<string, string>();
  /** The practice mode a session is in right now (last command pressed). */
  private currentCommand = new Map<string, string>();
  /** The SKILL.md that governs the practice the learner is in right now, pinned
   *  to the SYSTEM prompt for the rest of the session. System, not history: the
   *  history is pruned when the context fills, and the grading contract is the
   *  last thing that may quietly disappear. */
  private activeSkill = new Map<string, { name: string; body: string }>();
  /** The learner-state block (read-db.py output) for this session, pinned to
   *  the system prompt so the history's pruning can never take it away. */
  private activeState = new Map<string, string>();
  /** Fingerprints of the exercise the tutor asked last turn, per session. */
  private lastAsked = new Map<string, string[]>();
  /** The learner's last message, so a record derived from the tutor's text can
   *  say what was actually answered. */
  private lastAnswer = new Map<string, string>();
  /** True while the turn being run was opened by the learner typing an answer;
   *  false for a button. Only an answer can be the one that finishes a lesson. */
  private answerInFront = new Map<string, boolean>();
  /** The review item the server handed the tutor for the exercise now on
   *  screen, and the one before it — the answer arriving this turn belongs to
   *  the previous assignment, not the one being made now. */
  private assignedItem = new Map<string, AssignedItem>();
  private gradingItem = new Map<string, AssignedItem>();
  /** The same, for the curriculum's competence in free practice (Mix, Vocabulary):
   *  the one the exercise now on screen was built for, and the one being graded.
   *  `followed` is set once the tutor's exercise was seen to be about it. */
  private assignedCompetence = new Map<string, AssignedCompetence & { followed?: boolean; shown?: boolean }>();
  private gradingCompetence = new Map<string, AssignedCompetence & { followed?: boolean; shown?: boolean }>();
  /** Items dispensed today, so the queue is not handed out twice. */
  private usedItems = new Map<string, string[]>();
  /** Weak patterns already drilled this session, and the one in hand. */
  private usedDrills = new Map<string, string[]>();
  private lastDrill = new Map<string, string>();
  /** What each practice has asked today, keyed "<session>|<command>". */
  private askedByPractice = new Map<string, string[]>();
  /** How many turns in a row the pacing note has said exactly the same thing.
   *  An unchanging note means the lesson is not advancing — worth a log line,
   *  because on 2026-09-16 it stayed unchanged for twenty-five turns and
   *  nobody found out until the children gave up. */
  private noteStall = new Map<string, { note: string; turns: number }>();
  /** The running number for "## Exercise {N}: ..." / "## Question {N}: ..."
   *  headings, per session+practice — see alignExerciseNumber. */
  private exerciseSeq = new Map<string, number>();
  /** Consecutive answered turns that produced no detectable grade — see
   *  bounceReason. Reset to 0 the moment a turn grades again. */
  private ungradedStreak = new Map<string, number>();
  /** Sessions already bounced once — never twice in a row for the same
   *  session, so a fresh session that is itself unlucky does not loop. */
  private bounced = new Set<string>();

  constructor(opts: {
    db: FluentDB;
    root: string;
    dataDir: () => string;
    models: Models;
    deep: DeepEvaluator;
    emit: (e: SSEEvent) => void;
  }) {
    this.db = opts.db;
    this.root = opts.root;
    this.dataDirFn = opts.dataDir;
    this.models = opts.models;
    this.deep = opts.deep;
    this.emit = opts.emit;
    this.tools = buildTools({
      root: opts.root,
      dataDir: opts.dataDir,
      deep: opts.deep,
      gradingItem: (sessionId) => this.gradingItem.get(sessionId) ?? null,
      gradingCompetence: (sessionId) => this.recordCompetence(sessionId),
    });
  }

  private dataDir() {
    return this.dataDirFn();
  }

  /** The deep model's context window, from config. */
  private contextTokens(): number {
    const n = Number(process.env.FLUENT_DEEP_CTX);
    if (Number.isFinite(n) && n > 0) return n;
    try {
      const cfg = JSON.parse(fs.readFileSync(path.join(this.root, "config", "fluent.json"), "utf8"));
      const ctx = Number(cfg?.models?.deep?.ctx);
      if (Number.isFinite(ctx) && ctx > 0) return ctx;
    } catch {
      /* fall through */
    }
    return 32768;
  }

  private maxOutputTokens(): number {
    try {
      const cfg = JSON.parse(fs.readFileSync(path.join(this.root, "config", "fluent.json"), "utf8"));
      const n = Number(cfg?.models?.deep?.max_tokens);
      if (Number.isFinite(n) && n > 0) return n;
    } catch {
      /* default below */
    }
    return 4096;
  }

  // ---- system prompt -------------------------------------------------------

  private readRuleFile(filename: string): string {
    const p = path.join(this.root, filename);
    try {
      return fs.readFileSync(p, "utf8");
    } catch {
      return "";
    }
  }

  private readAgentBody(agent: string): string {
    const file = AGENT_FILES[agent] ?? "learner.md";
    const p = path.join(this.root, "prompts", "agents", file);
    try {
      const raw = fs.readFileSync(p, "utf8");
      return raw.startsWith("---") ? raw.slice(raw.indexOf("\n---", 4) + 4) : raw;
    } catch {
      return "";
    }
  }

  private buildSystemPrompt(agent: string, sessionId?: string): string {
    const blocks: string[] = [];
    for (const f of ["AGENTS.md", "LEARNING_SYSTEM.md"]) {
      const c = this.readRuleFile(f);
      if (c.trim()) blocks.push(`Instructions from: ${path.join(this.root, f)}\n\n${c.trim()}`);
    }
    const body = this.readAgentBody(agent).trim();
    if (body) blocks.push(body);
    // Shared behavioral rules: single source concatenated into EVERY agent
    // (rollback = delete these 3 lines; agent files keep their legacy copies).
    const shared = this.readRuleFile(path.join("prompts", "agents", "rules.md")).trim();
    if (shared) blocks.push(`Shared behavioral rules (apply on top of everything above):\n\n${shared}`);
    // The practice the learner is in. Last block, so it wins any generic rule
    // above it, and present on EVERY turn — not only on the turn that happened
    // to load it.
    const state = sessionId ? this.activeState.get(sessionId) : undefined;
    if (state) {
      blocks.push(
        `Who you are teaching right now, and where they are. This is the live state ` +
          `of their profile and databases — treat it as fact:\n\n${state}`
      );
    }
    const practice = skillBlock(sessionId ? this.activeSkill.get(sessionId) : undefined);
    if (practice) blocks.push(practice);
    return blocks.join("\n\n");
  }

  // ---- history reconstruction ----------------------------------------------

  private historyToMessages(sessionId: string): ChatMsg[] {
    const messages = this.db.getMessages(sessionId);
    const out: ChatMsg[] = [];
    for (const m of messages) {
      const role = String(m.data["role"] ?? "assistant");
      const parts = this.db.getParts(m.id);
      if (role === "user") {
        const text = parts
          .filter((p) => (p.data["type"] as string) === "text")
          .map((p) => String(p.data["text"] ?? ""))
          .join("\n");
        if (text.trim()) out.push({ role: "user", content: text });
        continue;
      }
      // assistant: group tool parts, then the final text part.
      const toolParts = parts.filter((p) => (p.data["type"] as string) === "tool");
      const textParts = parts.filter((p) => (p.data["type"] as string) === "text");
      if (toolParts.length) {
        const tcs = toolParts.map((p) => {
          const state = p.data["state"] as { input?: unknown; output?: unknown } | undefined;
          return {
            id: String(p.data["callID"] ?? ""),
            type: "function",
            function: {
              name: String(p.data["tool"] ?? ""),
              arguments: JSON.stringify(state?.input ?? {}),
            },
          };
        });
        out.push({ role: "assistant", content: null, tool_calls: tcs });
        for (const p of toolParts) {
          const state = p.data["state"] as { output?: unknown } | undefined;
          out.push({
            role: "tool",
            tool_call_id: String(p.data["callID"] ?? ""),
            content: String(state?.output ?? ""),
          });
        }
      }
      const finalText = textParts.map((p) => String(p.data["text"] ?? "")).join("\n").trim();
      out.push({ role: "assistant", content: finalText });
    }
    return out;
  }

  // ---- persistence ---------------------------------------------------------

  private persistUserTurn(sessionId: string, text: string, agent: string, isCommand: boolean): MessageRow {
    const msg = this.db.insertMessage(sessionId, {
      role: "user",
      time: { created: Date.now() },
      agent,
      model: { providerID: "fluent-deep", modelID: "deep" },
      summary: { diffs: [] },
    });
    this.db.insertPart(msg.id, sessionId, { type: "text", text });
    // SSE: confirm the user message (chip or plain bubble).
    this.emit({
      type: "message.updated",
      properties: { info: this.db.getMessageView(msg).info },
    });
    return msg;
  }

  private createAssistantMessage(sessionId: string, agent: string, model: ModelConfig): MessageRow {
    const msg = this.db.insertMessage(sessionId, {
      parentID: null,
      role: "assistant",
      agent,
      model: { providerID: model.name === "deep" ? "fluent-deep" : "llama-face", modelID: model.name },
      cost: 0,
      tokens: { total: 0 },
    });
    // Emit before any part so the UI creates the message + "pensant…" placeholder.
    this.emit({ type: "message.updated", properties: { info: this.db.getMessageView(msg).info } });
    return msg;
  }

  // True once the tutor has produced any text in this session (i.e. this
  // command continues, rather than starts, the practice). Best-effort.
  private sessionHasAssistantText(sessionId: string): boolean {
    try {
      for (const m of this.db.getMessages(sessionId)) {
        if (String(m.data["role"] ?? "assistant") !== "assistant") continue;
        for (const p of this.db.getParts(m.id)) {
          const d = p.data as Record<string, unknown>;
          if (d["type"] === "text" && String(d["text"] ?? "").trim()) return true;
        }
      }
    } catch {
      /* best-effort; never break the turn */
    }
    return false;
  }

  // ---- turn drivers --------------------------------------------------------

  async runCommand(sessionId: string, commandName: string, agentArg: string): Promise<TurnOutcome> {
    const dataDir = this.dataDir();
    if (!this.sessionOpenedWith.has(sessionId)) {
      this.sessionOpenedWith.set(sessionId, commandName);
      if (this.sessionOpenedWith.size > 500) this.sessionOpenedWith.clear();
    }
    // Which practice the learner is in right now — the Lesson credits only
    // answers given inside it.
    const prevCommand = this.currentCommand.get(sessionId);
    this.currentCommand.set(sessionId, commandName);
    if (this.currentCommand.size > 500) this.currentCommand.clear();
    this.answerInFront.set(sessionId, false);
    // The level test is run by the server (docs/ESQUEMA-APRENENTATGE.md): no model in the loop.
    if (commandName === "fluent-checkpoint") return this.checkpointTurn(sessionId, "start", "");
    // A button starts a new exercise in a new practice, so the previous practice's
    // exercise is no longer the one being answered. Left standing, a Writing
    // answer was graded as the answer to the Vocabulary word shown before it
    // ("llibre" ← "I have two childs…"): the note said so, the tutor obeyed, and
    // two false records went to the database. The reply to the button sets it
    // again when it presents an exercise the fingerprints recognise.
    this.lastAsked.delete(sessionId);
    // Second and later commands of a session do not need the state block again:
    // it is already in the history, and re-running the directive would re-inject
    // several KB of JSON per command.
    const continuing = this.sessionHasAssistantText(sessionId);
    const resolved = await loadCommand(commandName, {
      root: this.root,
      dataDir,
      env: { ...process.env as Record<string, string> },
      skipDirectives: continuing,
    });
    if (!resolved) {
      throw new Error(`unknown command: ${commandName}`);
    }
    const agent = resolved.agent; // frontmatter wins (tutor / tutor-fast)
    // Continuing session (not a fresh start): mark it ON the recorded turn so
    // the model continues instead of re-greeting (prompt rules alone lose to
    // the greeting template). Skipped for fluent-end (own finalization flow).
    let body = resolved.body;
    if (commandName !== "fluent-end" && continuing) {
      // Measured live, 2026-09-22, test-en: pressing Reading right after Speaking
      // did not switch the content — the tutor kept asking Speaking-style
      // "Question N" cards under the Reading button, twice in one session. The
      // generic "continue the ongoing practice" wording did not say WHICH
      // practice, so with Speaking still fresh in the history the model just
      // kept going. When the button actually changed the practice, say so by
      // name and say to drop the previous one — the same instruction a switch
      // between any two skills needs, not just this pair.
      body +=
        prevCommand && prevCommand !== commandName
          ? `\n\n(Switching practice: the history above contains turns from ${prevCommand}, but the learner just pressed the button for ${commandName}. Do NOT greet, do NOT show the practice menu, and do NOT continue ${prevCommand}'s exercises — stop that practice now and follow ONLY the ${commandName} instructions above for the next exercise.)`
          : `\n\n(Continuing session: the history above already contains tutor turns. Do NOT greet, do NOT show the practice menu — continue the ongoing practice directly: evaluate any pending answer, otherwise present the next exercise.)`;
    }
    if (resolved.skill) {
      this.activeSkill.set(sessionId, resolved.skill);
      if (this.activeSkill.size > 200) this.activeSkill.clear();
    }
    if (resolved.state) {
      this.activeState.set(sessionId, resolved.state);
      if (this.activeState.size > 200) this.activeState.clear();
    }
    this.persistUserTurn(sessionId, body, agent, true);
    const system = this.buildSystemPrompt(agent, sessionId);
    const history = this.historyToMessages(sessionId);
    const outcome = await this.executeTurn(sessionId, agent, system, history, this.tools.definitions);

    // Auto-run fluent-db-updater for fluent-end command to finalize Capa B
    if (commandName === "fluent-end") {
      await this.runDbUpdater(sessionId, dataDir);
    }

    return outcome;
  }

  async runMessage(sessionId: string, text: string, agentArg: string): Promise<TurnOutcome> {
    const agent = agentArg || "learner";
    // A test in progress answers itself: the server asks, grades and cuts the course.
    const cmd = this.currentCommand.get(sessionId);
    if ((cmd === "fluent-checkpoint" || cmd === undefined) && this.checkpointRunning()) {
      return this.checkpointTurn(sessionId, "answer", text);
    }
    this.answerInFront.set(sessionId, true);
    if (this.answerInFront.size > 500) this.answerInFront.clear();
    this.lastAnswer.set(sessionId, text);
    if (this.lastAnswer.size > 500) this.lastAnswer.clear();
    this.persistUserTurn(sessionId, text, agent, false);
    const system = this.buildSystemPrompt(agent, sessionId);
    return this.executeTurn(sessionId, agent, system, this.historyToMessages(sessionId), this.tools.definitions);
  }

  // ---- the level test ------------------------------------------------------
  // Picked, asked and graded by hooks/curriculum.py (`checkpoint start|answer`); this
  // only carries its text into the conversation as a tutor message. Nothing here
  // depends on the model, so a certificate never depends on a model's mood.

  /** A test started TODAY and not finished (after a restart the map of commands is empty, and the
   *  next message is still the answer to the question on screen). */
  private checkpointRunning(): boolean {
    try {
      const run = JSON.parse(fs.readFileSync(path.join(this.dataDir(), "checkpoint-run.json"), "utf8")) as { day?: string };
      return run.day === new Date(Date.now() - new Date().getTimezoneOffset() * 60_000).toISOString().slice(0, 10);
    } catch {
      return false;
    }
  }

  private runCheckpointCli(action: "start" | "answer", text: string): { ok: boolean; text: string; done?: boolean } {
    try {
      const args = [
        "python3", path.join(this.root, "hooks", "curriculum.py"), "checkpoint", action, "--auto",
        "--data", this.dataDir(), "--today", new Date(Date.now() - new Date().getTimezoneOffset() * 60_000).toISOString().slice(0, 10),
      ];
      if (action === "answer") args.push("--text", text);
      const r = Bun.spawnSync(args, {
        cwd: this.root,
        env: { ...process.env, FLUENT_DATA_DIR: this.dataDir(), FLUENT_ROOT: this.root },
        stdout: "pipe",
        stderr: "pipe",
      });
      const j = JSON.parse(r.stdout.toString() || "{}") as { ok?: boolean; text?: string; done?: boolean };
      if (r.exitCode === 0 && typeof j.text === "string") return { ok: Boolean(j.ok), text: j.text, done: j.done };
    } catch {
      /* fall through */
    }
    return { ok: false, text: "The level test is not available right now. Please try again later." };
  }

  private async checkpointTurn(sessionId: string, action: "start" | "answer", text: string): Promise<TurnOutcome> {
    const agent = "learner";
    this.db.touchSession(sessionId);
    this.persistUserTurn(sessionId, action === "start" ? "Execute /fluent-checkpoint now." : text, agent, action === "start");
    const out = this.runCheckpointCli(action, text);
    const { model } = await resolveModel(agent, this.models);
    const msg = this.createAssistantMessage(sessionId, agent, model);
    const view = () => this.db.getMessageView(msg);
    this.db.insertPart(msg.id, sessionId, { type: "text", text: out.text });
    this.emit({ type: "message.part.updated", properties: { part: view().parts.at(-1) } });
    // The test is over (or could not start): the next message is an ordinary one.
    if (out.done || !out.ok) this.currentCommand.delete(sessionId);
    this.emit({ type: "session.progress", properties: { sessionID: sessionId, ...this.sessionProgress(sessionId) } });
    this.emit({ type: "session.idle", properties: { sessionID: sessionId } });
    return { info: view().info, parts: view().parts };
  }

  private async executeTurn(
    sessionId: string,
    agent: string,
    system: string,
    history: ChatMsg[],
    tools: ToolDefinition[]
  ): Promise<TurnOutcome> {
    // Update activity timestamp at start of turn to prevent sweeper from
    // marking session stale during long model processing (deep model on large contexts).
    this.db.touchSession(sessionId);
    // A session the learner comes back to is not finished, whatever the
    // sweeper decided 30 minutes ago.
    try {
      if (this.db.reopenIfFinalized(sessionId)) {
        // The sweeper reads its own copy of the flag from session-draft.json;
        // clearing only the database one would leave it skipping this session.
        const draftPath = path.join(this.dataDir(), "session-draft.json");
        try {
          const draft = JSON.parse(fs.readFileSync(draftPath, "utf8"));
          if (draft.capa_b_sid === sessionId || draft.session_id === sessionId) {
            delete draft.capa_b_done;
            fs.writeFileSync(draftPath, JSON.stringify(draft, null, 2));
          }
        } catch {
          /* no draft yet */
        }
        console.log(`[Fluent] ↩ session ${sessionId} reopened — Capa B will run again at the end`);
      }
    } catch {
      /* best-effort: never block a turn over bookkeeping */
    }

    // How many answers were on record BEFORE this turn. The counter used to be
    // read only from the tutor's "Score: N/10"; a tutor that calls
    // fluent_record_answer and forgets the sentence then graded nothing as far
    // as the server knew. Measured: four structured records, counter at 0 of 12.
    const recordsBefore = this.recordCount(sessionId);

    // Pacing: appended to what the model sees, never persisted into the
    // learner's own message.
    const note = this.pacingNote(sessionId);
    this.logNote(sessionId, note);
    if (note) {
      const prev = this.noteStall.get(sessionId);
      const turns = prev && prev.note === note ? prev.turns + 1 : 1;
      this.noteStall.set(sessionId, { note, turns });
      if (this.noteStall.size > 500) this.noteStall.clear();
      // The stall warning is about the LESSON not advancing. Free practice's note is
      // a list of what she already knows, and it legitimately stays the same for
      // as long as nothing new is answered correctly.
      if (turns === 4 && this.currentCommand.get(sessionId) === "fluent-review") {
        console.log(
          `[Fluent] ⚠ session ${sessionId}: the pacing note has not changed in 4 turns — ` +
            `the lesson is not advancing. Note: ${note.slice(0, 120)}`
        );
      }
    }

    // Keep the request inside the model's context. Without this the turn fails
    // outright — seen live: 41808 tokens against a 40960 window — and the
    // learner gets an error instead of an exercise. Safe to do now that the
    // server, not the history, remembers what has already been asked.
    const budget = historyBudget(
      this.contextTokens(),
      estimateTokens(system) + estimateTokens(note ?? ""),
      this.maxOutputTokens()
    );
    const pruned = pruneHistory(history, budget);
    if (pruned.dropped) {
      console.log(
        `[Fluent] ✂ session ${sessionId}: dropped ${pruned.dropped} old message(s) to fit the context ` +
          `(history ≈${pruned.estimatedTokens} tok, budget ${budget})`
      );
    }
    history = pruned.messages;

    if (note) history = [...history, { role: "system", content: note }];

    const { model } = await resolveModel(agent, this.models);
    const msg = this.createAssistantMessage(sessionId, agent, model);
    const view = () => this.db.getMessageView(msg);

    // Streaming (FLUENT_STREAM=1): the first delta creates an empty text part,
    // the rest arrive as message.part.delta events — the shape web/app.js
    // already knows. The part row is written once, when the segment closes, so
    // the transcript on disk matches what the learner saw without one SQLite
    // write per token.
    let streamPartId: string | null = null;
    let streamText = "";
    const emitPart = (partId: string) => {
      const part = view().parts.find((p) => p.id === partId) ?? view().parts.at(-1);
      this.emit({ type: "message.part.updated", properties: { part } });
    };
    const flushStream = () => {
      if (!streamPartId) return;
      this.db.updatePart(streamPartId, { type: "text", text: streamText });
      const id = streamPartId;
      streamPartId = null;
      streamText = "";
      emitPart(id);
    };
    const onDelta = (text: string) => {
      if (!streamPartId) {
        streamPartId = this.db.insertPart(msg.id, sessionId, { type: "text", text: "" }).id;
        streamText = "";
        emitPart(streamPartId);
      }
      streamText += text;
      this.emit({
        type: "message.part.delta",
        properties: {
          sessionID: sessionId,
          messageID: msg.id,
          partID: streamPartId,
          field: "text",
          delta: text,
        },
      });
    };

    // Persist + emit each part as soon as it is produced, so the UI streams it.
    const onPart = (step: TurnPart) => {
      if (step.kind === "tool") {
        flushStream(); // close any text the model streamed before calling a tool
        const t = step as ToolStep;
        const part = this.db.insertPart(msg.id, sessionId, {
          type: "tool",
          tool: t.name,
          callID: t.callID,
          state: { status: t.status, input: t.args, output: t.output },
        });
        emitPart(part.id);
        return;
      }
      if (streamPartId) {
        // Same segment the learner just watched arrive: close it with the
        // final text instead of appending a duplicate part.
        streamText = this.tidyTutorText(sessionId, step.text);
        flushStream();
        return;
      }
      const part = this.db.insertPart(msg.id, sessionId, {
        type: "text",
        text: this.tidyTutorText(sessionId, step.text),
      });
      emitPart(part.id);
    };

    const startedAt = Date.now();
    let metrics: TurnMetrics | undefined;
    try {
      const result = await runTurn(
        model, system, history, tools, 6, onPart,
        { sessionID: sessionId, messageID: msg.id, dataDir: this.dataDir() },
        onDelta
      );
      metrics = result.metrics;
    } catch (e) {
      // El face pot caure a mig torn: un sol reintent amb deep abans de rendir-se.
      if (model.name !== "deep" && isConnError(e)) {
        console.log(`[Fluent] face cau a mig torn (${model.baseURL}) → reintent amb deep`);
        try {
          flushStream(); // whatever the face managed to stream stays on disk
          const retry = await runTurn(
            this.models.deep, system, history, tools, 6, onPart,
            { sessionID: sessionId, messageID: msg.id, dataDir: this.dataDir() },
            onDelta
          );
          this.logTurn(sessionId, agent, this.models.deep.name, startedAt, history, retry.metrics);
          return { info: view().info, parts: view().parts };
        } catch (e2) {
          e = e2;
        }
      }
      flushStream();
      const text = `⚠️ ${e instanceof Error ? e.message : String(e)}`;
      this.db.insertPart(msg.id, sessionId, { type: "text", text });
      this.emit({ type: "message.part.updated", properties: { part: view().parts.at(-1) } });
      this.emit({ type: "session.error", properties: { sessionID: sessionId, error: { message: text } } });
    }

    await this.enforceTurn(sessionId, msg.id, view, system, history, tools, model, onPart, onDelta);

    this.logTurn(sessionId, agent, model.name, startedAt, history, metrics);

    // Credit the answer just graded, to the DAY. The score marker is in the
    // tutor's text whether or not it remembered the tool call, so the counter
    // moves either way — which is the whole reason it is read from here.
    this.creditTurn(sessionId, view().parts, recordsBefore);

    // Where the learner is now. Emitted after persistence so the count includes
    // the answer just graded.
    this.emit({
      type: "session.progress",
      properties: { sessionID: sessionId, ...this.sessionProgress(sessionId) },
    });

    // session.idle → incremental persistence (accumulate-session.py)
    this.emit({ type: "session.idle", properties: { sessionID: sessionId } });
    this.runAutoPersistence(sessionId);

    // The session itself has gone past reliable use — not one bad exercise,
    // the model no longer doing the one thing every turn must do (grade) or
    // the context already having needed real turns cut to fit. Bounced once,
    // never twice for the same session (see `bounced`): the frontend starts a
    // clean one, and a session that is unlucky right after that is a new
    // problem, not this one repeating.
    if (!this.bounced.has(sessionId)) {
      const reason = bounceReason({
        historyDropped: pruned.dropped > 0,
        ungradedStreak: this.ungradedStreak.get(sessionId) ?? 0,
      });
      if (reason) {
        this.bounced.add(sessionId);
        if (this.bounced.size > 500) this.bounced.clear();
        console.log(`[Fluent] ⟲ session ${sessionId}: bouncing (${reason})`);
        this.emit({ type: "session.bounce", properties: { sessionID: sessionId, reason } });
      }
    }

    return { info: view().info, parts: view().parts };
  }

  // ---- session pacing ------------------------------------------------------
  // How many answers this session has graded, from the structured records, plus
  // the skill of the last one. Cheap: one small append-only file per session.
  private gradedSoFar(sessionId: string): {
    count: number;
    lastSkill?: string;
    itemIds: string[];
  } {
    try {
      const file = path.join(this.dataDir(), ".records", `${sessionId}.jsonl`);
      const lines = fs.readFileSync(file, "utf8").split("\n").filter((l) => l.trim());
      let lastSkill: string | undefined;
      const itemIds: string[] = [];
      for (let i = lines.length - 1; i >= 0; i--) {
        try {
          const rec = JSON.parse(lines[i]!) as { skill?: string; item_id?: string };
          if (rec.skill && !lastSkill) lastSkill = rec.skill;
          if (rec.item_id) itemIds.push(rec.item_id);
        } catch {
          /* a torn line: keep looking */
        }
      }
      if (lines.length) return { count: lines.length, lastSkill, itemIds };
    } catch {
      /* no records yet — fall through */
    }
    // No records: count what the tutor actually wrote. The indicator must not
    // depend on the model remembering a tool call.
    return { count: countGradedInText(this.assistantTexts(sessionId)), itemIds: [] };
  }

  /**
   * How many records this session's file actually holds. No fallback.
   *
   * `gradedSoFar()` deliberately falls back to counting the tutor's score lines
   * when there is no records file, because the learner's progress indicator
   * must not depend on a tool call. That fallback made it useless for the one
   * question that needs a straight answer — *did the tool write anything?* —
   * and the derived-record path, which asked exactly that, never fired once.
   */
  private recordCount(sessionId: string): number {
    try {
      const file = path.join(this.dataDir(), ".records", `${sessionId}.jsonl`);
      return fs.readFileSync(file, "utf8").split("\n").filter((l) => l.trim()).length;
    } catch {
      return 0;
    }
  }

  /** The tutor's own messages in a session, oldest first. */
  private assistantTexts(sessionId: string): string[] {
    const out: string[] = [];
    try {
      for (const m of this.db.getMessages(sessionId)) {
        const view = this.db.getMessageView(m);
        if ((view.info as { role?: string }).role !== "assistant") continue;
        const text = view.parts
          .filter((p) => (p as { type?: string }).type === "text")
          .map((p) => String((p as { text?: string }).text ?? ""))
          .join("\n");
        if (text.trim()) out.push(text);
      }
    } catch {
      /* best-effort */
    }
    return out;
  }

  /** Today's spaced-repetition gate for this session. */
  private reviewGate(sessionId: string, gradedItemIds: string[]): ReviewGate {
    try {
      const dir = this.dataDir();
      const profile = JSON.parse(fs.readFileSync(path.join(dir, "learner-profile.json"), "utf8"));
      const sr = JSON.parse(fs.readFileSync(path.join(dir, "spaced-repetition.json"), "utf8"));
      return resolveReviewGate({
        profile,
        sr,
        today: new Date().toISOString().slice(0, 10),
        sessionTarget: resolveSessionTarget(profile),
        firstCommand: this.sessionOpenedWith.get(sessionId),
        gradedItemIds,
      });
    } catch {
      return NO_GATE;
    }
  }

  private pacingPrefs(): { target: number; mode: ReturnType<typeof resolveStopMode> } {
    try {
      const profile = JSON.parse(
        fs.readFileSync(path.join(this.dataDir(), "learner-profile.json"), "utf8")
      );
      return { target: resolveSessionTarget(profile), mode: resolveStopMode(profile) };
    } catch {
      return { target: resolveSessionTarget(null), mode: "soft" };
    }
  }

  /**
   * One graded answer, credited to today.
   *
   * A turn grades at most one answer, and the tutor's own "Score: 9/10" is the
   * evidence — not the tool call, which a 14B forgets. Inside the Lesson it
   * counts twice over: once for the day, once against the badge.
   */
  private creditTurn(sessionId: string, parts: Record<string, unknown>[], recordsBefore = -1): void {
    try {
      const text = parts
        .filter((p) => (p as { type?: string }).type === "text")
        .map((p) => String((p as { text?: string }).text ?? ""))
        .join("\n");

      // What was asked this turn — tracked in every practice, not only the
      // Lesson, because the loop we are guarding against is not specific to it.
      const asked = exerciseFingerprints(text);
      // Was the exercise on screen the one the server assigned a competence for?
      {
        const comp = this.assignedCompetence.get(sessionId);
        if (comp) {
          comp.shown = asked.length > 0;
          comp.followed = comp.shown && followsCompetence(comp, text);
        }
      }
      // What the learner was answering: the exercise that was on screen BEFORE
      // this turn. Captured before lastAsked is overwritten below.
      const answered = (this.lastAsked.get(sessionId) ?? [])[0];
      const answeredAll = [...(this.lastAsked.get(sessionId) ?? [])];
      if (asked.length) {
        const prev = this.lastAsked.get(sessionId) ?? [];
        if (prev.length && asked.every((a) => prev.includes(a))) {
          console.log(
            `[Fluent] ↻ session ${sessionId}: same exercise twice in a row ("${asked[0]}")`
          );
          this.logGuard(sessionId, `repeated in a row: ${asked[0]}`, text);
        }
        this.lastAsked.set(sessionId, asked);
        if (this.lastAsked.size > 500) this.lastAsked.clear();
      }

      // Remember what she has ANSWERED CORRECTLY today, in EVERY practice: that is
      // what must not come back. It used to be everything that had been shown,
      // which also banned an exercise she walked away from (fine to show again)
      // and one she got wrong (SM-2 wants it back). The exercise just answered
      // is the one on screen BEFORE this reply, and the score is in this reply.
      {
        const prevAsked = answeredAll;
        const score = scoreOfReply(text);
        if (
          this.answerInFront.get(sessionId) === true &&
          prevAsked.length &&
          score !== null &&
          score >= KNOWN_SCORE
        ) {
          const key = `${sessionId}|${this.currentCommand.get(sessionId) ?? "-"}`;
          const here = this.askedByPractice.get(key) ?? [];
          for (const label of prevAsked) if (!here.includes(label)) here.push(label);
          this.askedByPractice.set(key, here.slice(-40));
          if (this.askedByPractice.size > 500) this.askedByPractice.clear();
          const plan = this.lessonPlan();
          const before = plan.covered.length;
          for (const label of prevAsked) {
            if (!plan.covered.includes(label)) plan.covered.push(label);
          }
          if (plan.covered.length > 40) plan.covered = plan.covered.slice(-40);
          if (plan.covered.length !== before) writePlan(this.dataDir(), plan);
        }
      }

      // Two witnesses that an answer was graded, and the structured one is the
      // better: a tool call is a fact, a sentence is a formatting habit. Either
      // is enough. Requiring the sentence alone froze Iona's lesson at 0 of 12
      // while she worked through thirteen exercises.
      const gradedNow =
        countGradedInText([text]) > 0 ||
        (recordsBefore >= 0 && this.recordCount(sessionId) > recordsBefore);

      // Real exercises, not a synthetic probe: an answered turn that produced no
      // grade at all is the model failing at the one thing every turn must do.
      // Two in a row is the signal (see bounceReason) — never counted for a
      // button turn, which has nothing to grade in the first place.
      if (this.answerInFront.get(sessionId) === true) {
        const streak = gradedNow ? 0 : (this.ungradedStreak.get(sessionId) ?? 0) + 1;
        this.ungradedStreak.set(sessionId, streak);
        if (this.ungradedStreak.size > 500) this.ungradedStreak.clear();
      }

      if (!gradedNow) return;

      // Grading with nobody having answered is not grading. A turn opened by a
      // BUTTON — 🎓 Lesson, 📚 Vocabulary — carries no answer, and when the
      // tutor decorated its opening reply with a "Score: 2/10" the server
      // credited an exercise nobody had been asked yet: the plan came out
      // `done: 1, credited: []` before the first question. Measured
      // 2026-09-19; in the rig it aborted four of six executions, and for a
      // learner it silently costs her an exercise at the top of every lesson.
      if (!(this.lastAnswer.get(sessionId) ?? "").trim()) {
        console.log(
          `[Fluent] ↻ session ${sessionId}: a score with no answer behind it — not counted`
        );
        this.logGuard(sessionId, "graded with no answer", text);
        return;
      }

      // The tutor graded in prose and did not call fluent_record_answer — the
      // usual case, measured across three live lessons: six good corrections,
      // zero calls, and nothing at all reaching the databases. Everything the
      // call would have carried is already in the text, because the learner had
      // to read it. So take it from there.
      if (recordsBefore >= 0 && this.recordCount(sessionId) === recordsBefore) {
        // `answeredAll` was captured above, BEFORE `this.lastAsked` was
        // overwritten with the exercise this same reply just asked next —
        // that overwrite already happened a few lines up. deriveRecord must
        // not read `this.lastAsked` itself: by the time it runs it would get
        // the NEW exercise, not the one this answer was actually for.
        // Measured 2026-09-22: "I ___ (swim)..." recorded against the answer
        // "are", which was for the PREVIOUS exercise ("There ___ a lot of
        // people...") — every derived record was one exercise off.
        this.deriveRecord(sessionId, text, answeredAll);
      }

      const inLesson = this.currentCommand.get(sessionId) === "fluent-review";
      // Same principle as `lesson`: only credited while that specific button's
      // flow is the active one, never by an equivalent exercise mix happens to
      // surface on its own — a daily "did you also do one of these" reminder,
      // not a gate (2026-09-22, Albert).
      const inSpeaking = this.currentCommand.get(sessionId) === "fluent-speaking";
      const inReading = this.currentCommand.get(sessionId) === "fluent-reading";
      const dir = this.dataDir();
      bumpDaily(dir, {
        graded: 1,
        ...(inLesson ? { lesson: 1 } : {}),
        ...(inSpeaking ? { speaking: 1 } : {}),
        ...(inReading ? { reading: 1 } : {}),
      });
      // One answer, one credit. Consumed here so that a later turn with no
      // answer of its own — a button, a second assistant message in the same
      // tool loop — cannot count this one again.
      this.lastAnswer.delete(sessionId);

      if (inLesson) {
        const plan = this.lessonPlan();
        // One credit per exercise. The tutor that graded "xxx", "banana" and
        // "zzz" against the same single question six times over drove the badge
        // to 6 of 6 with one exercise asked. An unidentifiable exercise still
        // counts, so a fingerprinting miss can never cost the learner progress.
        const credited = plan.credited ?? [];
        if (answered && credited.includes(answered)) {
          // Not an anomaly: the guard doing its job, and it belongs with the
          // other guard events rather than in the warning channel. ⚠ is for
          // something wrong that nobody is fixing; this is something wrong
          // being fixed.
          console.log(`[Fluent] ↻ session ${sessionId}: "${answered}" already counted — not twice`);
          this.logGuard(sessionId, `already counted: ${answered}`, text);
          return;
        }
        if (answered) {
          credited.push(answered);
          plan.credited = credited.slice(-60);
        }
        if (plan.done < plan.total) {
          plan.done += 1;
          if (plan.slot && !plan.slot_done && text.toLowerCase().includes(plan.slot)) {
            plan.slot_done = true;
          }
          writePlan(dir, plan);
        }
        if (plan.done >= plan.total && plan.total > 0) {
          const tally = creditLesson(dir);
          console.log(`[Fluent] 🎓 lesson done (${plan.total} exercises) — ${tally.completed} total`);
        }
      }
    } catch {
      /* the count is a nicety; the answer is not */
    }
  }

  /** Is this id really in the learner's queue? The tool validates the same
   *  thing before it writes; a derived record has no other referee. */
  private itemExists(id: string): boolean {
    try {
      const sr = JSON.parse(
        fs.readFileSync(path.join(this.dataDir(), "spaced-repetition.json"), "utf8")
      );
      return Boolean(sr?.items && Object.prototype.hasOwnProperty.call(sr.items, id));
    } catch {
      return false;
    }
  }

  /** One line per guard event, beside the turn metrics.
   *
   *  The server log lives in /tmp and is gone by the time anyone asks what
   *  happened; the profile is where the evidence has to be, next to the turn it
   *  belongs to. Twice a run has been argued about because nobody could see
   *  whether the guard had fired. */
  private logGuard(sessionId: string, note: string, text: string): void {
    try {
      const dir = path.join(this.dataDir(), ".metrics");
      fs.mkdirSync(dir, { recursive: true });
      fs.appendFileSync(
        path.join(dir, "guards.jsonl"),
        JSON.stringify({ ts: Date.now(), session: sessionId,
                         note: note.slice(0, 160), head: text.slice(0, 1500) }) + "\n",
        "utf8"
      );
    } catch {
      /* best-effort */
    }
  }

  /** What the server told the tutor this turn, next to what the learner said.
   *
   *  The guard and the note can contradict each other ("this item is the next
   *  exercise" vs "a DIFFERENT exercise"), and the only way to tell is to read
   *  both for the same turn. Kept apart from guards.jsonl on purpose: it is
   *  not an intervention, and mixing them would inflate every guard count. */
  private logNote(sessionId: string, note: string | null): void {
    try {
      const dir = path.join(this.dataDir(), ".metrics");
      fs.mkdirSync(dir, { recursive: true });
      const item = this.assignedItem.get(sessionId);
      const comp = this.assignedCompetence.get(sessionId);
      fs.appendFileSync(
        path.join(dir, "notes.jsonl"),
        JSON.stringify({
          ts: Date.now(),
          session: sessionId,
          command: this.currentCommand.get(sessionId) ?? null,
          answer: (this.lastAnswer.get(sessionId) ?? "").slice(0, 80),
          assigned: item ? { id: item.id, content: item.content } : null,
          competence: comp ? { id: comp.id, name: comp.name, kind: comp.kind ?? null } : null,
          last_asked: this.lastAsked.get(sessionId) ?? [],
          note: note ? note.slice(0, 2000) : null,
        }) + "\n",
        "utf8"
      );
    } catch {
      /* best-effort */
    }
  }

  /** The two things the server knows better than the tutor: what the score
   *  means, and where the lesson actually is. */
  private tidyTutorText(sessionId: string, text: string): string {
    // The model's own reasoning, when it leaks: a whole <think>…</think> block or a
    // lone "</think>" (seen on a Writing exercise, on the learner's screen).
    const clean = String(text ?? "")
      .replace(/<think>[\s\S]*?<\/think>\s*/gi, "")
      .replace(/<\/?think>\s*/gi, "");
    const out = alignMarkersToScore(clean);
    const command = this.currentCommand.get(sessionId);
    if (command === "fluent-review") {
      try {
        const lesson = this.lessonWithAnswerInFront(sessionId);
        return alignLessonHeader(out, lesson.done, lesson.total);
      } catch {
        return out;
      }
    }
    // Free practice (Go, Speaking...) has no total to count down to — just a
    // running number the model is supposed to keep in its own head. Vocabulary
    // has its own "{N}/{total}" template and is left to it. See exerciseSeq.
    if (command && command !== "fluent-vocab" && hasExerciseHeader(out)) {
      try {
        const key = `${sessionId}|${command}`;
        const n = (this.exerciseSeq.get(key) ?? 0) + 1;
        this.exerciseSeq.set(key, n);
        if (this.exerciseSeq.size > 500) this.exerciseSeq.clear();
        return alignExerciseNumber(out, n);
      } catch {
        return out;
      }
    }
    return out;
  }

  /**
   * Make the tutor write the turn again when the turn does not move the lesson.
   *
   * Once. Never twice: a second failure is a tutor that cannot do it today, and
   * a loop here costs the learner a minute of staring at nothing. If the retry
   * is no better, the first reply stands — a flawed exercise beats a blank
   * screen, and the log says what happened.
   */
  private async enforceTurn(
    sessionId: string,
    messageId: string,
    view: () => { info: unknown; parts: Record<string, unknown>[] },
    system: string,
    history: ChatMsg[],
    tools: ToolDefinition[],
    model: ModelConfig,
    onPart: Parameters<typeof runTurn>[5],
    onDelta: Parameters<typeof runTurn>[7]
  ): Promise<void> {
    try {
      const parts = view().parts;
      const last = [...parts].reverse().find((p) => (p as { type?: string }).type === "text") as
        | { id?: string; text?: string }
        | undefined;
      const text = String(last?.text ?? "");
      if (!last?.id || !text.trim()) return;

      const inLesson = this.currentCommand.get(sessionId) === "fluent-review";
      const lesson = this.lessonWithAnswerInFront(sessionId);
      const graded = scoreOfReply(text);
      const justKnown =
        this.answerInFront.get(sessionId) === true && graded !== null && graded >= KNOWN_SCORE
          ? (this.lastAsked.get(sessionId) ?? [])
          : [];
      const langs = this.learnerLanguages();
      const note = pictureGuard(text) ?? languageDirectionGuard(text, langs.target, langs.native) ?? turnGuard({
        inLesson,
        pending: lesson.pending,
        // What she has answered correctly — plus the exercise this very reply is
        // grading, when it grades it as known: creditTurn has not run yet, and
        // showing the exercise she just got right straight away is the repeat.
        coveredToday: [...this.lessonPlan().covered, ...justKnown],
        askedHere: [
          ...(this.askedByPractice.get(
            `${sessionId}|${this.currentCommand.get(sessionId) ?? "-"}`
          ) ?? []),
          ...justKnown,
        ],
        asked: exerciseFingerprints(text),
        graded: countGradedInText([text]) > 0,
        closing: /session complete|review session complete/i.test(text),
        due: lesson.due,
        replyText: text,
        oneAtATime: this.currentCommand.get(sessionId) === "fluent-vocab",
        buttonTurn: this.answerInFront.get(sessionId) === false,
        assigned: inLesson ? this.assignedItem.get(sessionId) ?? null : null,
        competence: inLesson ? null : this.assignedCompetence.get(sessionId) ?? null,
        grading: inLesson && this.answerInFront.get(sessionId) === true
          ? this.gradingItem.get(sessionId) ?? null
          : null,
        answerText: this.lastAnswer.get(sessionId) ?? null,
        answering:
          this.answerInFront.get(sessionId) === true
            ? (this.lastAsked.get(sessionId) ?? [])[0] ?? null
            : null,
      });
      if (!note) return;

      console.log(`[Fluent] ↻ session ${sessionId}: ${note.slice(0, 80)}…`);
      this.logGuard(sessionId, note, text);
      // The rewrite starts from scratch, and a model told only "ask the next card"
      // picks the one it just asked (measured: "llibre" answered 10/10, then asked
      // again by the rewrite of the very next turn). Say which ones are off limits.
      const avoid = [
        ...new Set([...this.lessonPlan().covered, ...justKnown].map((a) => String(a).trim()).filter(Boolean)),
      ];
      const exerciseOnly = isExerciseGuard(note);
      // The mirror case: the exercise on screen is fine and the feedback is what is
      // missing. Rewriting the whole turn made the model grade the NEXT card.
      const gradingNow =
        inLesson && this.answerInFront.get(sessionId) === true
          ? this.gradingItem.get(sessionId) ?? null
          : null;
      const feedbackOnly = isFeedbackGuard(note) && trailingExercise(text) !== null;
      const retryNote =
        (avoid.length > 0 && !/already asked/i.test(note)
          ? `${note} Not any of these — she already got them right today: ${avoid
              .slice(-40)
              .map((a) => `"${a}"`)
              .join(", ")}.`
          : note) +
        (exerciseOnly
          ? ` The feedback already shown stays exactly as it is: write ONLY the next exercise — ` +
            `no feedback, no correction, no score.`
          : feedbackOnly
            ? ` The next exercise is already on screen and stays as it is: write ONLY the feedback on ` +
              `the learner's answer — the verdict, "Correct version:" and "**Score: N/10**" — and stop ` +
              `after the score line. No new exercise.`
            : ``);
      const retry = await runTurn(
        model,
        system,
        [...history, { role: "assistant", content: text }, { role: "system", content: retryNote }],
        tools, 3,
        () => {
          /* the retry's parts are not persisted separately: it replaces the text */
        },
        { sessionID: sessionId, messageID: messageId, dataDir: this.dataDir() },
        () => {
          /* no streaming on a retry: the learner already saw nothing */
        }
      );
      let better = alignMarkersToScore(String(retry.text ?? "").trim());
      if (!better) return;
      // A rewrite that drops the correction is worse than the repetition it was
      // meant to fix: the learner loses her feedback to gain a different
      // question. Measured — nine rewrites in three runs, and the marker and the
      // correct version gone from a third of the replies.
      let spliced = false;
      if (feedbackOnly) {
        const merged = mergeFeedbackOnly(text, better, gradingNow);
        if (!merged) {
          console.log(`[Fluent] ↻ session ${sessionId}: the feedback rewrite is unusable — keeping the first reply`);
          this.logGuard(sessionId, "rewrite rejected: feedback lost", better);
          return;
        }
        better = alignMarkersToScore(merged);
        spliced = true;
      }
      if (exerciseOnly) {
        // Keep the first reply's feedback and take only the exercise from the
        // rewrite: a whole new turn grades the answer the learner has not given.
        const only = exerciseOnlyOf(better);
        const merged = only ? spliceFeedback(text, only) : null;
        if (merged) {
          better = alignMarkersToScore(merged);
          spliced = true;
        }
      }
      const MARK = /[🟢🟡🔴✅❌]/u;
      const lostVersion = text.includes("Correct version:") && !better.includes("Correct version:");
      const lostMarker = MARK.test(text) && !MARK.test(better);
      if (!spliced && (lostVersion || lostMarker)) {
        // The rewrite is usually just the next exercise. The feedback is in the
        // first reply: put the two together instead of throwing the exercise away.
        const merged = spliceFeedback(text, better);
        if (merged) {
          better = alignMarkersToScore(merged);
          spliced = true;
        }
      }
      if (!spliced && (lostVersion || lostMarker)) {
        console.log(
          `[Fluent] ↻ session ${sessionId}: the rewrite lost the feedback — keeping the first reply`
        );
        this.logGuard(sessionId, "rewrite rejected: feedback lost", better);
        return;
      }
      this.db.updatePart(String(last.id), { type: "text", text: better });
      this.emit({
        type: "message.part.updated",
        properties: { part: view().parts.find((p) => (p as { id?: string }).id === last.id) },
      });
      console.log(`[Fluent] ↻ session ${sessionId}: turn rewritten`);
      this.logGuard(sessionId, spliced ? "rewritten (feedback kept, exercise replaced)" : "rewritten", better);
    } catch (e) {
      console.log(
        `[Fluent] ↻ session ${sessionId}: guard failed, keeping the first reply ` +
          `(${e instanceof Error ? e.message : String(e)})`
      );
    }
  }

  /**
   * Write the record the tutor should have called `fluent_record_answer` for.
   *
   * Only ever a fallback: a real tool call always wins, because it carries the
   * item_id and this cannot (the id is the tutor's to know, and guessing one
   * would corrupt the review schedule). What this does recover is the part that
   * was being lost completely — the score, the corrections and the categories
   * that mistakes-db and every count downstream are built from.
   */
  private deriveRecord(sessionId: string, text: string, askedBefore: string[]): void {
    try {
      const parsed = parseFeedback(text);
      if (!parsed) return;
      const answer = (this.lastAnswer.get(sessionId) ?? "").trim();
      if (!answer) return;
      const corrections = parsed.corrections
        .map((c) => ({ ...c, category: normalizeCategory(c.category) ?? "grammar" }))
        .filter((c) => c.wrong && c.right);
      // The exercise THIS answer was for — captured by the caller before
      // `this.lastAsked` was overwritten with whatever this same reply asks
      // next. Reading `this.lastAsked` here directly would get the wrong one.
      const asked = askedBefore;
      // The item this answer was for is the one the server handed out for the
      // exercise that was on screen — not a guess made afterwards from the
      // text. Still checked against the queue before it is written: an id that
      // is not there would advance the wrong schedule, silently.
      const item = this.gradingItem.get(sessionId);
      const known = item ? this.itemExists(item.id) : false;
      const quality = Math.max(0, Math.min(5, Math.floor(parsed.score / 2)));
      const record = {
        record_id: `${sessionId}:derived:${Date.now()}`,
        session_id: sessionId,
        ts: Date.now(),
        skill: parsed.skill ?? "vocabulary",
        exercise: (asked[0] ?? parsed.correctVersion ?? "").slice(0, 200),
        learner_answer: answer.slice(0, 500),
        score: Math.round(parsed.score),
        corrections,
        ...(item && known ? { item_id: item.id, sm2_quality: quality } : {}),
        ...(this.recordCompetence(sessionId) ? { competency: this.recordCompetence(sessionId) } : {}),
        derived: true,
      };
      const dir = path.join(this.dataDir(), ".records");
      fs.mkdirSync(dir, { recursive: true });
      fs.appendFileSync(path.join(dir, `${sessionId}.jsonl`), JSON.stringify(record) + "\n", "utf8");
      console.log(
        `[Fluent] ✍ session ${sessionId}: record derived from the tutor's text ` +
          `(${record.score}/10, ${corrections.length} correction(s)) — the tool was not called`
      );
    } catch {
      /* best-effort: never cost the learner their answer */
    }
  }

  /**
   * Today's lesson plan — made once, then worked through.
   *
   * It used to be recomputed from the live queue on every call, which moved the
   * badge for the wrong reason (answering a review makes it stop being due, so
   * the total shrank under the learner) and left nothing to resume: press
   * Speaking halfway and come back, and the tutor started again at exercise 1
   * while the counter happily reached 6 of 6.
   */
  lessonPlan(): LessonPlan {
    const dir = this.dataDir();
    const date = todayISO();
    const existing = readPlan(dir, date);
    if (existing) return existing;

    let total = 0;
    try {
      const sr = JSON.parse(fs.readFileSync(path.join(dir, "spaced-repetition.json"), "utf8"));
      total = lessonTarget(sr, date).total;
    } catch {
      total = 0;
    }
    let slot: string | null = null;
    try {
      const mastery = JSON.parse(fs.readFileSync(path.join(dir, "mastery-db.json"), "utf8"));
      slot = lessonSkillSlot(readTally(dir).completed, skillDebts(mastery, date));
    } catch {
      /* no mastery db yet: no slot */
    }
    return writePlan(dir, { date, total, done: 0, covered: [], slot, slot_done: false });
  }

  /** Today's Lesson: what it is made of, and how much is left. */
  /**
   * The lesson as the tutor has to see it WHILE an answer is in front of it.
   *
   * The plan is credited after the reply, so when answer k arrives the plan says
   * k-1 done. The note then told the tutor "1 exercise still to go, do not
   * close" at the sixth answer of six: it obeyed, skipped the feedback and asked
   * a seventh exercise. Measured, six runs of six: the last answer of every
   * lesson got no feedback and the lesson never closed. The answer in front is
   * going to be credited in this very turn, so it counts here — for the note,
   * for the guards, and for the "Review k/6" header.
   *
   * Not for a retry of an exercise already credited (it is not credited twice),
   * and not for a button.
   */
  lessonWithAnswerInFront(sessionId: string): LessonView & { drills: number } {
    const answered = (this.lastAsked.get(sessionId) ?? [])[0];
    return withAnswerInFront(this.lessonState(), {
      inLesson: this.currentCommand.get(sessionId) === "fluent-review",
      isAnswer:
        this.answerInFront.get(sessionId) === true &&
        (this.lastAnswer.get(sessionId) ?? "").trim() !== "",
      alreadyCredited: Boolean(answered && (this.lessonPlan().credited ?? []).includes(answered)),
    });
  }

  lessonState(): LessonView & { drills: number } {
    const plan = this.lessonPlan();
    const date = todayISO();
    let due = 0;
    try {
      const sr = JSON.parse(fs.readFileSync(path.join(this.dataDir(), "spaced-repetition.json"), "utf8"));
      due = lessonTarget(sr, date).due;
    } catch {
      /* queue unreadable: the plan's total still stands */
    }
    let material = 0;
    try {
      material = drillMaterial(
        JSON.parse(fs.readFileSync(path.join(this.dataDir(), "mistakes-db.json"), "utf8"))
      );
    } catch {
      /* no mistakes-db yet: treat as no material, which is the truth */
    }
    let level: string | undefined;
    try {
      const prof = JSON.parse(
        fs.readFileSync(path.join(this.dataDir(), "learner-profile.json"), "utf8")
      );
      const raw = prof?.learner?.current_level;
      if (typeof raw === "string" && raw.trim()) level = raw.trim().toUpperCase();
    } catch {
      /* level is a nicety */
    }
    return {
      total: plan.total,
      done: Math.min(plan.done, plan.total),
      pending: Math.max(0, plan.total - plan.done),
      due,
      drills: Math.max(0, plan.total - due),
      slot: plan.slot_done ? null : plan.slot,
      material,
      level,
    };
  }

  /** Native and target language from the profile, in English ("Catalan", "English"). */
  private learnerLanguages(): { native?: string; target?: string } {
    try {
      const prof = JSON.parse(
        fs.readFileSync(path.join(this.dataDir(), "learner-profile.json"), "utf8")
      );
      const pick = (v: unknown) =>
        typeof v === "string" && v.trim() && !v.includes("{") ? v.trim() : undefined;
      return { native: pick(prof?.learner?.native_language), target: pick(prof?.learner?.target_language) };
    } catch {
      return {};
    }
  }

  /** The learner's CEFR level from the profile, upper-cased, or undefined. */
  private learnerLevel(): string | undefined {
    try {
      const prof = JSON.parse(
        fs.readFileSync(path.join(this.dataDir(), "learner-profile.json"), "utf8")
      );
      const raw = prof?.learner?.current_level;
      return typeof raw === "string" && raw.trim() ? raw.trim().toUpperCase() : undefined;
    } catch {
      return undefined;
    }
  }

  /** Where the learner is in this session — the UI shows it, deterministically. */
  sessionProgress(sessionId: string): {
    graded: number;
    goal: number;
    face: string;
    session: number;
    skill?: string;
    lesson: ReturnType<Agent["lessonState"]>;
    speaking: ReturnType<typeof skillBadge>;
    reading: ReturnType<typeof skillBadge>;
  } {
    const { count, lastSkill } = this.gradedSoFar(sessionId);
    const dir = this.dataDir();
    let goal = resolveDailyGoal(null);
    try {
      goal = resolveDailyGoal(
        JSON.parse(fs.readFileSync(path.join(dir, "learner-profile.json"), "utf8"))
      );
    } catch {
      /* default goal */
    }
    // The day is the unit, not the session: the streak, the review queue and
    // every rollup are daily, and closing the tab at lunchtime must not reset
    // the learner's afternoon to zero.
    const daily = readDaily(dir);
    const graded = daily.graded;
    return {
      graded,
      goal,
      face: dailyFace(graded, goal),
      session: count,
      skill: lastSkill,
      lesson: this.lessonState(),
      speaking: skillBadge(daily.speaking),
      reading: skillBadge(daily.reading),
    };
  }

  /** The wrap-up note for this turn, or null. Given once per session. */
  /**
   * The teacher's topics (`topics.txt`, or `topics.md`, in the profile), as a
   * note — or null when there is no file, it is empty, or it cannot be read.
   * Read every turn: editing the file takes effect on the next message, no
   * restart. The rotation follows the day and the answers so far, so every
   * topic gets its turn instead of the first two being repeated.
   */
  private topicsNoteFor(sessionId: string): string | null {
    try {
      for (const name of ["topics.txt", "topics.md"]) {
        const f = path.join(this.dataDir(), name);
        if (!fs.existsSync(f)) continue;
        const topics = parseTopics(fs.readFileSync(f, "utf8"));
        if (topics.length === 0) return null;
        const day = Math.floor(Date.parse(todayISO()) / 86_400_000) || 0;
        const seed = day + this.gradedSoFar(sessionId).count;
        return topicsNote(topics, seed, this.learnerLevel());
      }
    } catch {
      /* a topics file that cannot be read must never cost the learner a turn */
    }
    return null;
  }

  /**
   * The competence the next free-practice exercise is about (Phase 2 of
   * docs/ESQUEMA-APRENENTATGE.md), as a note — or null when the profile has no
   * curriculum. The choice is Python's (hooks/curriculum.py next); the server
   * only asks, hands it over, and checks afterwards that the exercise is about
   * it. Same pattern as the Lesson's item: the answer arriving now belongs to the
   * PREVIOUS assignment, so it moves to `grading` before a new one is made.
   */
  private curriculumNoteFor(sessionId: string): string | null {
    const prev = this.assignedCompetence.get(sessionId);
    const answering = this.answerInFront.get(sessionId) === true;
    if (prev && answering) this.gradingCompetence.set(sessionId, prev);
    else this.gradingCompetence.delete(sessionId);
    this.assignedCompetence.delete(sessionId);
    try {
      const args = [
        "python3", path.join(this.root, "hooks", "curriculum.py"), "next", "--auto",
        // The LOCAL day: the path takes its days from the records' timestamps that way.
        "--data", this.dataDir(), "--today", new Date(Date.now() - new Date().getTimezoneOffset() * 60_000).toISOString().slice(0, 10),
      ];
      // Only an exercise that was really put on screen counts as "the one just asked"
      // (a greeting or a menu is not).
      if (prev && answering && prev.shown) args.push("--last", prev.id);
      // Vocabulary asks one word at a time: only competences that have words.
      if (this.currentCommand.get(sessionId) === "fluent-vocab") args.push("--vocab");
      const r = Bun.spawnSync(args, {
        cwd: this.root,
        env: { ...process.env, FLUENT_DATA_DIR: this.dataDir(), FLUENT_ROOT: this.root },
        stdout: "pipe",
        stderr: "pipe",
      });
      if (r.exitCode !== 0) return null;
      const j = JSON.parse(r.stdout.toString() || "{}") as {
        id?: string; name?: string; can_do?: string; signals?: string[]; vocab?: boolean; kind?: string; note?: string;
      };
      if (!j.id || !j.note) return null;
      this.assignedCompetence.set(sessionId, {
        id: j.id, name: String(j.name ?? j.id), can_do: j.can_do,
        signals: Array.isArray(j.signals) ? j.signals : [], vocab: Boolean(j.vocab), kind: j.kind,
      });
      if (this.assignedCompetence.size > 500) this.assignedCompetence.clear();
      return j.note;
    } catch {
      /* a curriculum that cannot be read must never cost the learner a turn */
      return null;
    }
  }

  /** The competence to write on the record being made: only when the exercise it
   *  answers was seen to be about it, and not for vocabulary (Python resolves
   *  those from the word). */
  private recordCompetence(sessionId: string): string | null {
    const c = this.gradingCompetence.get(sessionId);
    return c && c.followed && !c.vocab ? c.id : null;
  }

  private pacingNote(sessionId: string): string | null {
    const { count, lastSkill, itemIds } = this.gradedSoFar(sessionId);
    const { target, mode } = this.pacingPrefs();

    // The session ceiling is gone by design. We agreed the Lesson is what has
    // an end and free play does not, so a hidden "stop at 12" would contradict
    // the thing the learner is being shown. It survives only where an admin
    // explicitly asks for a hard stop (`preferences.session_stop: "hard"`).
    if (mode === "hard" && !this.wrappedUp.has(sessionId)) {
      const note = wrapUpNote(count, target, lastSkill, mode);
      if (note) {
        this.wrappedUp.add(sessionId);
        if (this.wrappedUp.size > 500) this.wrappedUp.clear();
        console.log(`[Fluent] 🏁 session ${sessionId}: ${count} graded — asking the tutor to close`);
        // Closing beats reviewing: the session is over either way, and two
        // contradictory instructions in one turn is how a 14B model derails.
        return note;
      }
    }

    if (this.currentCommand.get(sessionId) !== "fluent-review") {
      // Outside the Lesson nothing is handed out, so nothing is being graded
      // against the queue.
      this.gradingItem.delete(sessionId);
      this.assignedItem.delete(sessionId);
    }
    // The curriculum hands out competences in free practice only.
    const cmdNow = this.currentCommand.get(sessionId) ?? "";
    const compNote =
      cmdNow === "fluent-learn" || cmdNow === "fluent-vocab" ? this.curriculumNoteFor(sessionId) : null;
    if (cmdNow !== "fluent-learn" && cmdNow !== "fluent-vocab") {
      this.gradingCompetence.delete(sessionId);
      this.assignedCompetence.delete(sessionId);
    }

    if (this.currentCommand.get(sessionId) === "fluent-review") {
      const lesson = this.lessonWithAnswerInFront(sessionId);
      if (lesson.pending > 0) {
        // STATE, not a script — see lessonNote() in pacing.ts for what that
        // distinction cost on 2026-09-16 and why it is not negotiable.
        // The item for the NEXT exercise. What is on screen right now was the
        // previous assignment, and that is what the answer arriving this turn
        // will be about — so it moves aside before a new one is made.
        const prev = this.assignedItem.get(sessionId);
        // Set it or clear it — never leave the last one standing. A stale
        // assignment outlives its lesson, and the record tool now trusts this
        // map: one forgotten delete and a Vocabulary answer advances a review
        // item nobody asked about.
        if (prev) this.gradingItem.set(sessionId, prev);
        else this.gradingItem.delete(sessionId);
        let assigned: AssignedItem | null = null;
        try {
          const sr = JSON.parse(
            fs.readFileSync(path.join(this.dataDir(), "spaced-repetition.json"), "utf8")
          );
          assigned = nextDueItem(sr, todayISO(), this.usedItems.get(sessionId) ?? []);
        } catch {
          /* no queue: the lesson runs on weak patterns, as before */
        }
        if (assigned) {
          this.assignedItem.set(sessionId, assigned);
          const used = this.usedItems.get(sessionId) ?? [];
          if (!used.includes(assigned.id)) used.push(assigned.id);
          this.usedItems.set(sessionId, used.slice(-60));
        } else {
          this.assignedItem.delete(sessionId);
        }
        // Nothing due: the lesson drills a weak pattern, and the SERVER says
        // which one. See nextDrill() for the six runs that made this necessary.
        let drill: AssignedDrill | null = null;
        if (!assigned) {
          try {
            const mis = JSON.parse(
              fs.readFileSync(path.join(this.dataDir(), "mistakes-db.json"), "utf8")
            );
            const usedDrills = this.usedDrills.get(sessionId) ?? [];
            drill = nextDrill(mis, usedDrills);
            // One pattern may hold several turns — a miss deserves a second
            // exercise, not a new subject — so it is only retired once the
            // tutor has actually moved on from it.
            if (drill && this.lastDrill.get(sessionId) !== drill.id) {
              const prev = this.lastDrill.get(sessionId);
              if (prev && !usedDrills.includes(prev)) usedDrills.push(prev);
              this.usedDrills.set(sessionId, usedDrills.slice(-60));
              this.lastDrill.set(sessionId, drill.id);
            }
          } catch {
            /* no mistakes-db: the tutor picks, as before */
          }
        }
        const base = lessonNote(
          lesson, this.lessonPlan().covered, this.lastAsked.get(sessionId)?.[0], assigned, drill
        );
        // Only where the tutor is choosing the subject itself: an assigned review
        // item or drill always wins over a topic.
        const topics = !assigned && !drill ? this.topicsNoteFor(sessionId) : null;
        return topics ? `${base} ${topics}` : base;
      }

      // The last answer of the lesson is graded in this very turn, so the item
      // that was on screen still has to reach its record — the lesson being
      // over does not mean the review did not happen.
      const last = this.assignedItem.get(sessionId);
      // Set it or clear it: a message after the lesson is over answers nothing.
      if (last) this.gradingItem.set(sessionId, last);
      else this.gradingItem.delete(sessionId);
      this.assignedItem.delete(sessionId);

      // The lesson is FINISHED. Without this the tutor received no instruction
      // at all once the count ran out and simply carried on — exercise 7, 8,
      // 9 — asking the same shape of question for ever. A lesson that does not
      // end is not a lesson, and for an eight-year-old it is just boredom.
      return (
        `Today's lesson is COMPLETE: all ${lesson.total} exercises are done. ` +
        `Do NOT present another exercise. Finish evaluating the answer in front of you, then close: ` +
        `one warm line saying the lesson is done, a two-line summary (what went well, what to work on), ` +
        `and invite them to pick any practice they like with the buttons at the top — or to stop for today. ` +
        `If this lesson reviewed queue items, end with the fluent:review_results block. ` +
        `If they answer again anyway, respond briefly and point at the buttons; do not start a new exercise. ` +
        `Say nothing about this instruction itself.`
      );
    }

    const gate = this.reviewGate(sessionId, itemIds);
    const gateNote = reviewGateNote(gate);
    if (gateNote) {
      this.gradingCompetence.delete(sessionId);
      this.assignedCompetence.delete(sessionId);
      return gateNote;
    }
    // Outside the Lesson there is no pacing to impose — but the one thing the
    // tutor cannot know is what it has already asked today, and without it
    // Vocabulary repeated a word between visits in every measured run.
    const free = practiceNote(
      this.lessonPlan().covered,
      this.lastAsked.get(sessionId)?.[0],
      this.answerInFront.get(sessionId) === true
    );
    const cmd = this.currentCommand.get(sessionId) ?? "";
    const topics = [
      "fluent-learn", "fluent-vocab", "fluent-writing", "fluent-speaking", "fluent-reading",
    ].includes(cmd)
      ? this.topicsNoteFor(sessionId)
      : null;
    if (this.currentCommand.get(sessionId) === "fluent-writing") {
      const w = writingLengthNote(this.learnerLevel());
      return [free, w, topics].filter(Boolean).join(" ") || null;
    }
    if (this.currentCommand.get(sessionId) === "fluent-vocab") {
      let v: string | null = null;
      try {
        const sr = JSON.parse(
          fs.readFileSync(path.join(this.dataDir(), "spaced-repetition.json"), "utf8")
        );
        v = vocabularyDueNote(sr, todayISO(), this.lessonPlan().covered, 5, this.learnerLanguages());
      } catch {
        /* no queue: the skill's own rules apply */
      }
      // A due word is a review the learner already owes; the competence waits. NOT any
      // `v`: vocabularyDueNote() always says something (the "every card is a noun…" rule),
      // and treating that as a due word dropped the competence in every Vocabulary turn
      // (measured 2026-09-21, curriculum 201107: 0 of 15 turns assigned).
      const dueWords = Boolean(v && v.includes("Words due for review today"));
      if (dueWords) this.assignedCompetence.delete(sessionId);
      return [free, v, dueWords ? null : compNote ?? topics].filter(Boolean).join(" ") || null;
    }
    return [free, compNote ?? topics].filter(Boolean).join(" ") || null;
  }

  // ---- per-turn metrics ----------------------------------------------------
  // With a local model the scarce resources are context and wall time, and
  // neither was measured: `usage` came back from llama.cpp and was thrown away.
  // One line per turn in the log, one JSON line per turn in the profile, so the
  // context question can be decided with numbers instead of guesses.
  private logTurn(
    sessionId: string,
    agent: string,
    modelName: string,
    startedAt: number,
    history: ChatMsg[],
    metrics?: TurnMetrics
  ) {
    const wallMs = Date.now() - startedAt;
    const m = metrics ?? {
      roundtrips: 0,
      toolCalls: 0,
      tools: [] as string[],
      promptTokens: 0,
      completionTokens: 0,
      modelMs: 0,
    };
    const secs = (ms: number) => (ms / 1000).toFixed(1);
    console.log(
      `[Fluent] ⏱ turn ${sessionId} · ${agent}/${modelName} · ${secs(wallMs)}s ` +
        `(model ${secs(m.modelMs)}s) · prompt ${m.promptTokens} tok · out ${m.completionTokens} tok · ` +
        `${m.roundtrips} roundtrip(s), ${m.toolCalls} tool call(s)` +
        `${m.tools?.length ? ` [${m.tools.join(", ")}]` : ""}, history ${history.length} msg`
    );
    try {
      const dir = path.join(this.dataDir(), ".metrics");
      fs.mkdirSync(dir, { recursive: true });
      fs.appendFileSync(
        path.join(dir, "turns.jsonl"),
        JSON.stringify({
          ts: Date.now(),
          session_id: sessionId,
          agent,
          model: modelName,
          wall_ms: wallMs,
          model_ms: m.modelMs,
          prompt_tokens: m.promptTokens,
          completion_tokens: m.completionTokens,
          roundtrips: m.roundtrips,
          tool_calls: m.toolCalls,
          tools: m.tools ?? [],
          history_messages: history.length,
        }) + "\n",
        "utf8"
      );
    } catch {
      /* best-effort; never break the turn */
    }
  }

  // ---- auto persistence (was the plugin's session.idle hook) ---------------

  private async runAutoPersistence(sessionId: string) {
    try {
      const root = this.root;
      const env = { ...process.env, FLUENT_DATA_DIR: this.dataDir(), FLUENT_PROJECT_DIR: root, FLUENT_ROOT: root };
      const proc = Bun.spawn(
        [
          "python3",
          path.join(root, "hooks", "accumulate-session.py"),
          "--session-id",
          sessionId,
        ],
        {
        cwd: root,
        env,
          stdout: "pipe",
          stderr: "pipe",
        }
      );
      await proc.exited;

      // Learner path (docs/ESQUEMA-APRENENTATGE.md, phase 0): tag the recorded
      // answers with the competences of this profile's curriculum. Derived from
      // the records and idempotent; it does nothing when the profile has no
      // curriculum, and it never blocks or breaks the persistence above.
      try {
        const cp = Bun.spawn(
          ["python3", path.join(root, "hooks", "curriculum.py"), "rebuild", "--auto", "--quiet", "--data", this.dataDir()],
          { cwd: root, env, stdout: "pipe", stderr: "pipe" }
        );
        await cp.exited;
      } catch {
        /* best-effort */
      }

      // Daily backup, once per day.
      const today = new Date().toISOString().slice(0, 10);
      if (this.lastDailyBackup === today) return;
      this.lastDailyBackup = today;
      Bun.spawn(["python3", path.join(root, "hooks", "session-end.py")], {
        cwd: root,
        env,
        stdout: "pipe",
        stderr: "pipe",
      });
    } catch {
      // best-effort; never break the turn
    }
  }

  private async runDbUpdater(sessionId: string, dataDir: string): Promise<void> {
    console.log(`[Fluent] 🔄 runDbUpdater called for ${sessionId}`);
    try {
      const { spawnSync } = await import("node:child_process");
      const root = this.root;
      const env = { ...process.env, FLUENT_DATA_DIR: dataDir, FLUENT_PROJECT_DIR: root, FLUENT_ROOT: root };
      const proc = spawnSync("python3", [
        path.join(root, "hooks", "persist-session.py"),
        sessionId,
        "--dir", dataDir
      ], {
        cwd: root,
        env,
        stdio: "inherit",
      });
      if (proc.status === 0) {
        console.log(`[Fluent] ✅ Capa B (persist-session) completed for ${sessionId}`);
        // Durable per-session marker: stops the sweeper from re-running it.
        try { this.db.markFinalized(sessionId); } catch { /* best-effort */ }
        // Mark Capa B done in session-draft.json to prevent sweeper re-runs
        const draftPath = path.join(dataDir, "session-draft.json");
        try {
          const draft = JSON.parse(fs.readFileSync(draftPath, "utf8"));
          draft.capa_b_done = true;
          draft.capa_b_sid = sessionId; // SQLite session id (the draft's own id is "session-NNN")
          fs.writeFileSync(draftPath, JSON.stringify(draft, null, 2));
        } catch { /* best-effort; never break the turn */ }
      } else {
        console.error(`[Fluent] ❌ Capa B (persist-session) failed for ${sessionId} (exit ${proc.status})`);
      }
    } catch (e) {
      console.error("[Fluent] ❌ runDbUpdater error:", e);
    }
  }
}

// OpenAI-style chat message shape used for llm.history.
export interface ChatMsg {
  role: string;
  content: string | null;
  tool_calls?: unknown;
  tool_call_id?: string;
}
